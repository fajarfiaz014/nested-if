#include <iostream>
using namespace std;

int main() {
    int password, code;

    cout << "Enter password: ";
    cin >> password;

    if (password == 1234) {
        cout << "Enter security code: ";
        cin >> code;

        if (code == 5678) {
            cout << "Access Granted";
        } else {
            cout << "Wrong Security Code";
        }
    } else {
        cout << "Wrong Password";
    }

    return 0;
}
