#include <iostream>
using namespace std;

int main() {
    int age;

    cout << "Enter your age: ";
    cin >> age;

    if (age >= 18) {
        if (age >= 21) {
            cout << "Eligible for all driving licenses";
        } else {
            cout << "Eligible for basic driving license";
        }
    } else {
        cout << "Not eligible for driving license";
    }

    return 0;
}
