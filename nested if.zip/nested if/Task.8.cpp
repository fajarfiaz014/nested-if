#include <iostream>
using namespace std;

int main() {
    int attendance, marks;

    cout << "Enter attendance percentage: ";
    cin >> attendance;

    if (attendance >= 75) {
        cout << "Enter marks: ";
        cin >> marks;

        if (marks >= 50) {
            cout << "Student is eligible and passed.";
        } else {
            cout << "Student is eligible but failed.";
        }
    } else {
        cout << "Not eligible due to low attendance.";
    }

    return 0;
}
