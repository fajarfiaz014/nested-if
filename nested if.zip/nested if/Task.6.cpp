#include <iostream>
using namespace std;

int main() {
    int units;

    cout << "Enter units: ";
    cin >> units;

    if (units > 0) {
        if (units <= 100) {
            cout << "Low Electricity Usage";
        } else {
            cout << "High Electricity Usage";
        }
    } else {
        cout << "Invalid Units";
    }

    return 0;
}
