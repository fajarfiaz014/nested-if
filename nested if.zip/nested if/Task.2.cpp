#include <iostream>
using namespace std;

int main() {
    int num;

    cout << "Enter a number: ";
    cin >> num;

    if (num >= 1) {
        if (num <= 100) {
            cout << "Number is between 1 and 100";
        } else {
            cout << "Number is greater than 100";
        }
    } else {
        cout << "Number is less than 1";
    }

    return 0;
}
