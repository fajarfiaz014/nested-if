#include <iostream>
using namespace std;

int main()
{
    int a, b, c;

    cout << "Enter three sides of triangle: ";
    cin >> a >> b >> c;

    if (a + b > c)
    {
        if (a + c > b)
        {
            if (b + c > a)
                cout << "Valid Triangle";
            else
                cout << "Invalid Triangle";
        }
        else
            cout << "Invalid Triangle";
    }
    else
        cout << "Invalid Triangle";

    return 0;
}
