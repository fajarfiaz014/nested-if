#include <iostream>
using namespace std;

int main() {
    int a, b, c;

    cout << "Enter three sides: ";
    cin >> a >> b >> c;

    if (a == b) {
        if (b == c) {
            cout << "Equilateral Triangle";
        } else {
            cout << "Isosceles Triangle";
        }
    } else {
        cout << "Scalene Triangle";
    }

    return 0;
}
