#include <iostream>
using namespace std;

int main() {
    int salary, years;

    cout << "Enter salary: ";
    cin >> salary;

    if (salary >= 50000) {
        cout << "Enter years of service: ";
        cin >> years;

        if (years >= 5) {
            cout << "Eligible for bonus";
        } else {
            cout << "Not eligible for bonus";
        }
    } else {
        cout << "Salary is below required limit";
    }

    return 0;
}
